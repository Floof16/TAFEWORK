﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace ABC_Tafe_Enrollment_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IwebService" in both code and config file together.
    [ServiceContract]
    public interface IwebService
    {
        [OperationContract]
        int insertStudent(string id, string name, DateTime dateEnrolled);

        [OperationContract]
        int insertCourse(string id, string name, Decimal cost);
        [OperationContract]
        int enroll(String courseID, String studentID);
        [OperationContract]
        List<Student> viewAllStudents();

        [OperationContract]
        List<Course> viewAllCourses();
        [OperationContract]
        List<Enrollment> getStudentEnrollement(string studentId);
        [OperationContract]
        List<Enrollment> getStudentsEnrolledInCourse(String courseID);
        [OperationContract]
        List<Course> Billing(string studentID);
    }
}
