﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
namespace ABC_Tafe_Enrollment_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "webService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select webService.svc or webService.svc.cs at the Solution Explorer and start debugging.
    public class webService : IwebService
    {
        public TafeDBEntities db = new TafeDBEntities();

        int IwebService.enroll(string courseID, string studentID)
        {
            Enrollment e = new Enrollment();
            e.CourseID = courseID;
            e.StudentID = studentID;
            e.Grade = "NR";
            db.Enrollments.Add(e);
            return db.SaveChanges();
          
        }

        int IwebService.insertCourse(string id, string name, decimal cost)
        {
            Course c = new Course();
            c.CourseID= id;
            c.CourseName= name;
            c.Cost = cost;
            db.Courses.Add(c);
            return db.SaveChanges();
        }

        int IwebService.insertStudent(string id, string name, DateTime dateEnrolled)
        {

            Student s = new Student();
            s.StudentID = id;
            s.StduentName = name;
            s.DateEnrolled = dateEnrolled;
            db.Students.Add(s);
            return db.SaveChanges();
        }
        public List<Student> viewAllStudents()
        {
            return db.Students.ToList() ;
        }
        public List<Course> viewAllCourses()
        {
            return db.Courses.ToList();
        }
        public List<Enrollment> getStudentEnrollement(string studentId)
        {

            return db.Enrollments.Where(e => e.StudentID == studentId).ToList();
        }
        public List<Enrollment> getStudentsEnrolledInCourse(string courseID)
        {
            return db.Enrollments.Where(e => e.CourseID == courseID).ToList();
        }
        public List<Course> Billing(string studentID)
        {
            List<Enrollment> studs = db.Enrollments.Where(s => s.StudentID== studentID).ToList();
            List<Course> c = new List<Course>();
            foreach (var s in studs)
            {
                Course crs = db.Courses.Find(s.CourseID);
                c.Add(crs);
            }
            return c;
        }
        
    }
}
