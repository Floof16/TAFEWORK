﻿using ABC_Ed_Services.EnrolmentServiceReference;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace ABC_Ed_Services
{
    [TestFixture]
  public  class TestClass
    {
        public IwebServiceClient proxy = new IwebServiceClient("BasicHttpBinding_IwebService");

        private TransactionScope scope;
        [SetUp]
        public void SetUp()
        {
            scope = new TransactionScope();
        }
        [TearDown]
        public void TearDown()
        {
            scope.Dispose();
       
        }
        [Test]
        public void Test()
        {
            Assert.IsNotNull(proxy.viewAllCourses());
        }
    }
}
