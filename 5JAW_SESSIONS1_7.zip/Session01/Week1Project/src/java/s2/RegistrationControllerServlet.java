/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s2;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Set;
import javax.faces.validator.Validator;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.ValidatorFactory;
import javax.validation.constraints.NotNull;

/**
 *
 * @author 000286128
 */
@WebServlet(name = "RegistrationControllerServlet", urlPatterns = {"/RegController"})
public class RegistrationControllerServlet extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        
        try (PrintWriter out = response.getWriter()) {

            Student S = new Student();
         
//            String id = request.getParameter("txtId");
//            String name = request.getParameter("txtName");
//            String address = request.getParameter("txtAddress");
//            String tel = request.getParameter("txtTel");
//            String email = request.getParameter("txtEmail");

       S.setId(request.getParameter("txtId"));
        S.setName(request.getParameter("txtName"));
        S.setAddress(request.getParameter("txtAddress"));
        S.setTel(request.getParameter("txtTel"));
        S.setEmail(request.getParameter("txtEmail"));
            /* TODO output your page here. You may use following sample code. */
            String id= S.getId();
            String name = S.getName();
            String tel = S.getTel();
            String email = S.getEmail();
            String add = S.getAddress();
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegistrationControllerServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Your Details Are As Follows "+ "</h1>");
            if(S.notNull(id)){
                if(S.isIdValid(id)){ 
                out.println("<h3>Your ID: "+ id + "</h3>");
                }
                 else{
                 out.println("<h3>Your ID was invalid </h3>");
                 id = "invalid";
                 S.setId(id);
            }
            }
            else{
                 out.println("<h3>Your ID was invalid </h3>");
                 id = "invalid";
                 S.setId(id);
            }
            if(S.notNull(name)){
                if(!S.hasNumber(name)){
                     out.println("<h3>Your name: "+ name + "</h3>");
                }
             else{
                 out.println("<h3>Your Name was invalid </h3>");
                 name = "invalid";
                 S.setName(name);
            }
            }
            else{
                 out.println("<h3>Your Name was invalid </h3>");
                 name = "invalid";
                 S.setName(name);
            }
            if(S.notNull(tel)){
                if(S.isPhoneValid(tel)){
                 out.println("<h3>Your telephone: "+ tel + "</h3>");
                }
                 else{
                 out.println("<h3>Your Telephone number was invalid </h3>");
                 tel = "invalid";
                 S.setTel(tel);
            }
            }
            else{
                 out.println("<h3>Your Telephone number was invalid </h3>");
                 tel = "invalid";
                 S.setTel(tel);
            }
            if(S.notNull(email)){
                if(S.isEmailValid(email)){
                 out.println("<h3>Your email: "+ email + "</h3>");
                }
                 else{
                 out.println("<h3>Your email was invalid </h3>");
                 email = "invalid";
                 S.setEmail(email);
            }
            }
            else{
                 out.println("<h3>Your email was invalid </h3>");
                 email = "invalid";
                 S.setEmail(email);
            }
            if(S.notNull(add)){
                 out.println("<h3>Your Address:  "+ add + "</h3>");
            }      
            else{
                 out.println("<h3>Your address was invalid </h3>");
                 add = "invalid";
                 S.setAddress(add);
            }

             //out.println("<h3>Using the ToString()"+ S.toString() + "</h3>");
             
           out.println("<a href=Registration.html>Back Home</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
