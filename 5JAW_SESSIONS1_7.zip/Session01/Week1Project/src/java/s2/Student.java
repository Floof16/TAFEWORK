/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s2;


import java.util.regex.*;



/**
 *
 * @author 000286128
 */
public class Student {


    private String id;

    private String name; 

    private String address; 

    private String tel; 

    private String email; 
    
    
    public Student() {
    }
    public boolean notNull(String i){
        
        if(i != ""){
                return true;
        }

        return false;
    }
    
    public boolean hasNumber(String i){
        for(int j = 0;j<i.length(); j++){
            if(Character.isDigit(i.charAt(j))){
                return true;
            }
            
        }
        return false;
    }

    public boolean isNumeric(String s){
        

           if(s.matches("-?\\d+(\\.\\d+)?")){
               return true;
           }

       
        return false;
    }
    public boolean isPhoneValid(String s){
               if(s.length() == 8 ){
                  return isNumeric(s);
       }
               return false;
    }
    
    public boolean isIdValid(String s){
                       if(s.length() == 6 ){
                  return isNumeric(s);
       }
                       return false;
    }
    
    public boolean isEmailValid(String s){
        Pattern p = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(s);
        boolean matchFound = m.matches();
        return matchFound;
    }
    public Student(String id, String name, String address, String tel, String email) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.tel = tel;
        this.email = email;
    }

    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    @Override
    public String toString() {
        return "Student{" + "id=" + id + ", name=" + name + ", address=" + address + ", tel=" + tel + ", email=" + email + '}';
    }

}
