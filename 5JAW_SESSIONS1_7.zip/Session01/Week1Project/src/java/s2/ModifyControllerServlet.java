/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s2;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 000286128
 */
@WebServlet(name = "ModifyControllerServlet", urlPatterns = {"/ModController"})
public class ModifyControllerServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String studId = request.getParameter("txtStudId");
            String studName = request.getParameter("txtStudName");
            String stream = request.getParameter("txtStream");
            String semester= request.getParameter("txtSemester");
            String oldCourse = request.getParameter("txtOCO");
            String newCourse = request.getParameter("txtNCO");
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ModifyControllerServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1> Your details <h1>");
            out.println("<h3>Student Id: "+studId+ "  <h3>");
            out.println("<h3>Name: "+studName+ "  <h3>");
            out.println("<h3>Stream: "+stream+ "  <h3>");
            out.println("<h3>Semester: "+semester+ "  <h3>");
            out.println("<h3>old Course Offerings: "+oldCourse+ "  <h3>");
            out.println("<h3>New Course Offerings: "+newCourse+ "  <h3>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
