/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s3;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 000286128
 */
@WebServlet(name = "pmServlet", urlPatterns = {"/pm"})
public class pmServlet extends HttpServlet {



    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet pmServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet pmServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       // processRequest(request, response);
       Cookie cookies[] = request.getCookies();
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
             
        out.println( "<head>" );
        out.println( "<title>whats your message?</title>" );
        out.println( "</head>" );
        
        out.println( "<body>" );
        out.print("<p> please write your name : </p>");
        out.print("<input type=\"text\" name=\"txtNameComparison\" /> ");
        

        String nameComparison = "txtNameComparison";
        
        if(cookies != null && cookies.length !=0){
              for(int i = 0; i < cookies.length; i++){
                  if(cookies[i].getName().equals(nameComparison)){
                      out.println("name: "+cookies[i].getName() +" your personalised message: " + cookies[i].getPath()+"<br />");
                      
                      
                  }
              }
            
            
        }
        else{
            out.println( "<h1>No Message for u</h1>" );
            out.println( "<p>go to the back of the line.</p>" );
        }
        out.println( "</body>" );
        out.println( "</html>" );
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        
        String name = request.getParameter("txtName");
        String message = request.getParameter("txtMessage");
        
        Cookie cookie = new Cookie(name, message);
        cookie.setMaxAge(100);
        response.addCookie( cookie ); 
        response.setContentType( "text/html" );
        PrintWriter out = response.getWriter();   
              // head section of document
      out.println( "<head>" );
      out.println( "<title>Welcome to Cookies</title>" );      
      out.println( "</head>" );

      // body section of document
      out.println( "<body>" );
      out.println( "<p>Welcome  " +
         name + "</p>" );

      out.println( "<p><a href = " +
         "\"./Lab03.html\">" +
         "Click here to choose change user</a></p>" );

      out.println( "<p><a href = \"cookies2\">" + 
        "Click here to get book recommendations</a></p>" );
      out.println( "</body>" );

      // end XHTML document
      out.println( "</html>" );
      out.close();    // close stream
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
