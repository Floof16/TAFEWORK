/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author 000286128
 */
public class Programmer {
    
    private String fName;
    private String lName;
    private String email;
    private String[] language;
    private String notificationIntervals;
    
    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String[] getLanguage() {
        return language;
    }

    public void setLanguage(String[] language) {
        this.language = language;
    }

    public String getNotificationIntervals() {
        return notificationIntervals;
    }

    public void setNotificationIntervals(String notificationIntervals) {
        this.notificationIntervals = notificationIntervals;
    }

    @Override
    public String toString() {
        return "Programmer{" + "fName=" + fName + ", lName=" + lName + ", email=" + email + ", language=" + language + ", notificationIntervals=" + notificationIntervals + '}';
    }

    public Programmer() {
    }

    public Programmer(String fName, String lName, String email, String[] language, String notificationIntervals) {
        this.fName = fName;
        this.lName = lName;
        this.email = email;
        this.language = language;
        this.notificationIntervals = notificationIntervals;
    }

    
}
