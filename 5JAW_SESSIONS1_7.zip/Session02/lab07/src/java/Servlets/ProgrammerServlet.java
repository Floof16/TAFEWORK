/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import Classes.Programmer;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 000286128
 */
@WebServlet(name = "ProgrammerServlet", urlPatterns = {"/ProgrammerServlet"})
public class ProgrammerServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            Programmer p = new Programmer();
            p.setfName(request.getParameter("firstName"));
            p.setlName(request.getParameter("lastName"));
            p.setEmail(request.getParameter("email"));
            p.setLanguage(request.getParameterValues("languages"));
            
            
             p.setNotificationIntervals(request.getParameter("notify"));
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProgrammerServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>PROGRAMMER INFORMATION </h1>");
            out.println("<h2>First Name :  " + p.getfName() + "</h2>");
            out.println("<h2>Last Name: " + p.getlName() + "</h2>");
            out.println("<h2>Email: " + p.getEmail() + "</h2>");
            out.println("<h2>Languages: </h2>");
            for(String lang:p.getLanguage()){
                out.println("<h3> "+lang +"</h3>");
            }
            out.println("<h2>Notification intervals:" +p.getNotificationIntervals() +"</h2>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
