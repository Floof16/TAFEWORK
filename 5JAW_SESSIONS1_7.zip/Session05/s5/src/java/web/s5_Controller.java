

package web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import tafe.java.web.TableFormatter;
import dao.Tafe_DAO;

public class s5_Controller extends HttpServlet {
  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Tafe_DAO dao = null;
        String action = request.getParameter("action");
        if(action == null) {
           response.sendRedirect("Main.html");
        }

        else {

           out.println("<html>");
           out.println("<head>");
           out.println("<title>Course Admin</title>");
           out.println("</head>");
           out.println("<body>");

            if(action.equals("all")){
                dao = new Tafe_DAO();
                try {
                     
                    out.println(TableFormatter.getData(dao.displayAll()));
                    
                }
                catch(Exception ex) {
                    out.println("No records to display");
                }
            }
            else if(action.equals("new")){
                dao = new Tafe_DAO();
                String id = request.getParameter("id");
                String name = request.getParameter("name");
                double cost = Double.parseDouble(request.getParameter("cost"));
                int num = dao.addNewCourse(id, name, cost);
                if(num>0){
                    out.println("New Course saved");
                }
                else {
                    out.println("New course could not be saved");
                }
            }
            else if(action.equals("change")){
                dao = new Tafe_DAO();
                String id = request.getParameter("courses");
                double cost = Double.parseDouble(request.getParameter("cost"));
                int num = dao.changeCourseCost(id, cost);
                if(num>0){
                    out.println("Mofication saved");
                }
                else {
                    out.println("Mofication NOT saved");
                }
            }
            else {
                out.println("invalid request");
            }
        }
       out.println("</body>");
       out.println("</html>");
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
