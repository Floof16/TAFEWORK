package dao;

import java.sql.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

//import javax.naming.*;
//import javax.sql.DataSource;


public class Tafe_DAO {
    public static final String driver = "org.apache.derby.jdbc.ClientDriver";
    public static final String url = "jdbc:derby://localhost:1527/Tafe";
    Connection connection;

    /** Creates a new instance of DataAccess */
    public Tafe_DAO() {
      
        try{
//            Class.forName(driver).newInstance();
//            connection = DriverManager.getConnection(url,"user1","password");
            Context ctx = new InitialContext();
            DataSource ds = (DataSource) ctx.lookup("jdbc/javaDB_Tafe");
            connection = ds.getConnection();
        }
        catch(Exception ex){
            System.out.println("Could not connect to database");
         //    System.out.println(ex.getMessage());
        }


        

       //Using a DataSource
        try {
            Context ctx = new InitialContext();
            DataSource ds = (DataSource)ctx.lookup("jdbc/javaDB_Tafe");
            connection = ds.getConnection();
                
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        
    }

   

    public ResultSet displayAll(){
        ResultSet rs = null;
        try{
            Statement s = connection.createStatement();
            rs = s.executeQuery("SELECT * FROM courses");
            //s.close();
            //connection.close();

        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return rs;
    }


    public int addNewCourse(String courseID, String courseName, double cost){
        int rows = 0;
        try{
            Statement s = connection.createStatement();
            rows = s.executeUpdate("INSERT INTO courses Values('" + courseID + "','" + courseName + "'," + cost+ ")");

            s.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return rows;
    }

     public int  changeCourseCost(String courseID, double cost){
        int rows = 0;
        try{
            Statement s = connection.createStatement();
            rows = s.executeUpdate("update courses set cost=" + cost + " where course_id='" + courseID +"'");

            s.close();
            connection.close();
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return rows;
    }
}
