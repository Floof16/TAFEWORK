package dao;

import java.util.*;
import java.io.*;
import java.sql.*;
import javax.sql.*;
import javax.naming.*;


public class TafeDAO2 {

  protected Connection con;
  protected PreparedStatement findCoursesPS;
  protected PreparedStatement getAllCoursesPS;
  public static final String driver = "org.apache.derby.jdbc.ClientDriver";
  public static final String url = "jdbc:derby://localhost:1527/Tafe";



  public TafeDAO2()throws Exception {
   //code to connect to database here
    Class.forName(driver).newInstance();
    con = DriverManager.getConnection(url,"user1","password");
    findCoursesPS = findCoursesSQL();
    getAllCoursesPS = getAllCoursesSQL();
    
  }

 
  public List getAllCourses() throws Exception{
    ResultSet rs = null;
    List list = new ArrayList();
    String id =""; String name =""; double cost = 0.0;
    
    rs = getAllCoursesPS.executeQuery();

    while(rs.next()) {
      id = rs.getString("course_id");
      name = rs.getString("course_name");
      cost = rs.getDouble ("cost");
      System.out.println(name);
      //list.add(new Course(id,name,cost));
    }
    rs.close();
    return null;
  }


  public  Object findCourses(String c)throws Exception {
    ResultSet rs = null;
    List list = new ArrayList();
    String id =""; String name =""; double cost = 0.0;
    String findParam = "%" + c + "%";
    findCoursesPS.setString(1,findParam);
    rs = findCoursesPS.executeQuery();

    while(rs.next()) {
      id = rs.getString("course_id");
      name = rs.getString("course_name");
      cost = rs.getDouble ("cost");
       System.out.println(name);
      //list.add(new Course(id,name,cost));
    }
    rs.close();
    return null;
  }

  protected PreparedStatement getAllCoursesSQL() throws Exception{
    return con.prepareStatement ("SELECT * FROM Courses");
  }

  protected PreparedStatement findCoursesSQL() throws Exception{
    return con.prepareStatement ("SELECT * FROM Courses "+
                                 "WHERE course_name like ? ");
  }
  
 

  
}