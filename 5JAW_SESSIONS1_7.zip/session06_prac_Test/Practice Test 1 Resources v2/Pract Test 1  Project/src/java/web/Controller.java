/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package web;

import dao.LibDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import tafe.java.web.TableFormatter;


@WebServlet(name="Controller", urlPatterns={"/Controller"}, initParams={@WebInitParam(name="datasource", value="jdbc/JavaDB_libDB")})
public class Controller extends HttpServlet {
   
   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // GET THE action parameter to determine what action is required
        String action = request.getParameter("action");

          //GET datasource init parameter
        String ds = this.getInitParameter("datasource");

      
        try {
           //Create an instance of the DAO and pass the appropriate parameter
           LibDAO libs = new LibDAO(ds);

           // if action is checkin use the appropriate method in the DAO
           //that returns a message indicating the success or not of the operation

           if(action.equals("Checkin")){
               // get member id
               // get book id
               // call appropriate dao method to chekin book
               String memberId = request.getParameter("member");
               String bookId = request.getParameter("book");
               libs.checkIn(memberId, bookId);

               
           }



           // if action is checkout use the appropriate method in the DAO and respond with an appropriate messge to the user
            if(action.equals("Checkout")){
                // get member id
                // get book id
                //call appropriate dao to checkout book
               String memberId = request.getParameter("member");
               String bookId = request.getParameter("book");
             if(  libs.checkOut(memberId, bookId)){
              out.println("success");   
             }
             else
             {
                 out.println("failed");
             }
              
           }

           // if action is view member borrowing history use the appropriate method in the DAO and Pass the result set to the TableFormatter class to display the outpu
           else if(action.equals("MemberHistory")){
               // get member id
               // call appropriate dao method to get books borrows by this member
               // use the TableFormatter.getData() to display the results
              String memberId = request.getParameter("member");
              out.println(TableFormatter.getData(libs.getMemberHistory(memberId)));
           }

            // if action is view book history use the appropriate methos in the DAO and Pass the result set to the TableFormatter class to display the output
             else if(action.equals("BookHistory")){
                 // get the book id
                 // call appropriate dao method to get the details of the members who have borrowed this book
                 //use the TableFormatter.getData() to display the results
              String bookId = request.getParameter("book");
              out.println(TableFormatter.getData(libs.getBookHistory(bookId)));
           }

        }

        catch(Exception ex) {
            out.println(ex.getMessage());
        }
        finally {
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
