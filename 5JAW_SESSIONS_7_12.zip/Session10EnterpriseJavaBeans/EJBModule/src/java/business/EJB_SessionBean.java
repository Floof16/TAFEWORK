/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business;

import javax.ejb.Stateless;

/**
 *
 * @author 000286128
 */
@Stateless
public class EJB_SessionBean implements EJB_SessionBeanRemote {

    @Override
    public String DisplayMessage() {
            return "welcome to EJB Session Bean Demo";
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
}
