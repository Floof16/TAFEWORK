/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Course;

import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author 000286128
 */
@WebServlet(name = "CourseServlet", urlPatterns = {"/courseServlet"})
public class CourseServlet extends HttpServlet {
    @PersistenceContext(unitName = "Topic9_ProjectPU2")
    private EntityManager em;
    @Resource
    private javax.transaction.UserTransaction utx;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String action = request.getParameter("action");
        String message = "NO MESSAGE";
        
        try (PrintWriter out = response.getWriter()) {
            
            /* TODO output your page here. You may use following sample code. */
 
            // List<Course> coruses = 
            
             if(action !=null){
                if(action.equals("all")){

                                    }
                
                           
                if(action.equals("add")){
                    String id = request.getParameter("id");
                    String name = request.getParameter("name");
                    Double cost = Double.parseDouble(request.getParameter("cost"));
                    Course s = new Course(id);
                    s.setCourseName(name);
                    s.setCost(cost);
                    this.persist(s);
                   message = "Course Added to DB";
                }
                
                else if(action.equals("find")) {
                    String id = request.getParameter("id");
                    Course s = this.find(id);
                    message = "Course Details: " + s;
                }
                else if(action.equals("edit")){
                    String id = request.getParameter("id");
                    Double cost = Double.parseDouble(request.getParameter("cost"));
                    this.edit(id, cost);
                    message = "Course cost Edited";
                }

            }
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CourseServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>" + message + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public void persist(Object object) {
        try {
            utx.begin();
            em.persist(object);
            utx.commit();
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
    }
     protected Course find(String id)
    {
       
        try {
            utx.begin();
            Course s = (Course) em.find(Course.class, id);
            utx.commit();
            return s;
        } catch (Exception ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            throw new RuntimeException(ex);
        } 
        
    }
  protected void edit(String id, Double cost) {
             try {
                 utx.begin();
                Course s = em.find(Course.class,id);
                s.setCost(cost);
                //em.flush();
                utx.commit();
            } catch (Exception e) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
                throw new RuntimeException(e);
            }
  }
}
