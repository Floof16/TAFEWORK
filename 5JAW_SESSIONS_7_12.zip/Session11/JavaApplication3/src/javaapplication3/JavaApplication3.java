/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

/**
 *
 * @author 000286128
 */
public class JavaApplication3 {
  

    public static void main(String[] args) 
{
	int[] input = new int[]{ 4, 4,3, 3, 3, 4, 1, 1, 1,2,1,4,5,4,4,4,4}; 
    
	int tripplets = 0; 
  

    for (int i = 0; i < input.length ; i++) 
    { 
  
        for (int j = i + 1; j < input.length; j++)  
        { 
   
            for (int k = j + 1; k < input.length; k++) 
            { 
                if (input[i] == input[j] && input[j]== input[k])
                {
                    tripplets++;
                    i=k;
                         break;
                } 
                
            } 
            break;
        } 
    } 

    System.out.println("" +tripplets);
	}
    
    }
